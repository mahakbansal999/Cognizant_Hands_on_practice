package com.ems.dto;

public interface EmployeeSummary {

    String getName();

    String getEmail();
}
