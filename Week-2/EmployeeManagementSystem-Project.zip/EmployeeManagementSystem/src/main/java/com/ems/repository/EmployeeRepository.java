package com.ems.repository;

import com.ems.dto.EmployeeDTO;
import com.ems.dto.EmployeeSummary;
import com.ems.entity.Employee;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    List<Employee> findByName(String name);

    List<Employee> findByDepartmentId(Long departmentId);

    @Query("SELECT e FROM Employee e WHERE e.email = :email")
    Optional<Employee> findByEmailCustom(@Param("email") String email);

    Page<Employee> findByNameContainingIgnoreCase(String name, Pageable pageable);

    List<EmployeeSummary> findEmployeeSummaryByDepartmentId(Long departmentId);

    @Query("SELECT new com.ems.dto.EmployeeDTO(e.name, e.email) FROM Employee e WHERE e.department.id = :deptId")
    List<EmployeeDTO> findEmployeeDTOByDepartmentId(@Param("deptId") Long deptId);
}
